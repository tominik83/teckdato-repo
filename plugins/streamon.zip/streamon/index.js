const express = require("express");
const app = express();

app.get("/radio", (req, res) => {
    res.json({ message: "Dobrodošli u Radioon plugin! I sve RADI sa i bez config!!!" });
});

app.use((req, res) => { res.status(404).json({ error: "Not Found" }); });

console.log('Radioon Plugin je startovan');

module.exports = app;