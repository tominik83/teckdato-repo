const express = require("express");
const app = express();

app.get("/chat", (req, res) => {
    res.json({ message: "Dobrodošli u chat plugin! I sve RADI!!!" });
});

app.use((req, res) => { res.status(404).json({ error: "Not Found" }); });

console.log('Chat Plugin je startovan');

module.exports = app;